Run the setup.bash script in the root of the assignment submission from the root folder first. This downloads images and sets them up.
Add the assignment3/4 folder into your Matlab path with subfolders first. Then go to assignment3/4 in Matlab and run unknownFaceRecognition.m. This will run the code and display the results of part 4.

Note that I have renamed image folders in the ORL database.
