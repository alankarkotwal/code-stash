Make sure you run the setup.bash script from the assignment3 folder before proceeding to run any code from the assignment. This will download and set up the images.
