Run the setup.bash script in the root of the assignment submission from the root folder first. This downloads images and sets them up.
Add the assignment3/1 folder into your Matlab path with subfolders, go to assignment3/1 in Matlab and run myDriver.m. This will run the code, display images and save them.
