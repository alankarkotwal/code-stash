Run the setup.bash script in the root of the assignment submission from the root folder first. This downloads images and sets them up.
Add the assignment3/3 folder into your Matlab path with subfolders first. Then go to assignment3/3 in Matlab and run faceReconstruction.m. This will run the code and display the reconstruction for the face selected by the variables folder and imageNo in the code. The code will also display the first 25 eigenfaces and their Fourier Transform log plots.

Note that I have renamed image folders in the ORL database.
