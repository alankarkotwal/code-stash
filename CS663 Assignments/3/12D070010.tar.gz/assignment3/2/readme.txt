Run the setup.bash script in the root of the assignment submission from the root folder first. This downloads images and sets them up.
Add the assignment3/2 folder into your Matlab path with subfolders. Then go to assignment3/2 in Matlab and run faceRecognition.m. This will run the code and display and plot recognition rates. To use data from the ORL dataset, set mode=1 in the code. Set mode=2 for the Yale dataset. 

Note that I have renamed image folders in the ORL database.
